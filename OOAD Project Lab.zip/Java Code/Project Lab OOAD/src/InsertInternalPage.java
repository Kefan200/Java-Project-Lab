import javax.swing.JInternalFrame;

public class InsertInternalPage extends JInternalFrame{

	public InsertInternalPage() {
		this.setClosable(true);
		this.setTitle("Insert Menu");
		this.setVisible(true);
	}

}