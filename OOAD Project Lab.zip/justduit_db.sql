-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2021 at 05:05 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `justduit_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeid` int(11) NOT NULL,
  `employeerole` varchar(101) NOT NULL,
  `employeename` varchar(101) NOT NULL,
  `employeeusername` varchar(101) NOT NULL,
  `employeestatus` varchar(12) NOT NULL,
  `employeesalary` int(51) NOT NULL,
  `employeepassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employeeid`, `employeerole`, `employeename`, `employeeusername`, `employeestatus`, `employeesalary`, `employeepassword`) VALUES
(6, 'sasa', 'sasas', 'sasas.id', 'Active', 400, 'sasas.id'),
(7, 'babab', 'bababa', 'bababa.id', 'Not Active', 300, 'bababa.id'),
(9, 'babab', 'sasas', 'babab', 'Active', 400, 'babab'),
(10, 'sasas', 'bababa', 'bababa', 'Not Active', 200, 'bababa');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `productdescription` varchar(255) NOT NULL,
  `productprice` int(11) NOT NULL,
  `productstock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `productname`, `productdescription`, `productprice`, `productstock`) VALUES
(10, 'sasas', 'bababa', 234, 2);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `productid` int(11) NOT NULL,
  `productquantity` int(11) NOT NULL,
  `productmethod` varchar(255) NOT NULL,
  `transactiondate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`productid`, `productquantity`, `productmethod`, `transactiondate`) VALUES
(2, 300, 'Credit', '2021-06-19'),
(3, 300, 'Credit', '2021-06-20'),
(4, 200, 'Credit', '2021-06-20'),
(5, 100, 'Credit', '2021-06-20'),
(6, 100, '-', '2021-06-22'),
(7, -18, 'Credit', '2021-06-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeid`),
  ADD UNIQUE KEY `employeeusername` (`employeeusername`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
